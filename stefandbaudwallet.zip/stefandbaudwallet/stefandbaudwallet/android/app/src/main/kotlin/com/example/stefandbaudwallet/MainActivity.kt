package com.example.stefandbaudwallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
