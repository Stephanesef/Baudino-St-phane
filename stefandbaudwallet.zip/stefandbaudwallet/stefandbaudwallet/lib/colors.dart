import 'dart:ui';

const Color primary = Color(0x00525f67);
const Color secondary = Color(0x0090a7b4);
const Color background = Color(0xFFF5F5F5);
const Color textWhite = Color(0xFFFFFFFF);
const Color textBlack = Color(0xFF000000);
const Color grey = Color(0xFF707070);